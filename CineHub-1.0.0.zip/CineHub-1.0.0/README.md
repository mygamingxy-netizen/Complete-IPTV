# CineHub

A clean movie & TV discovery and streaming interface.

## About

CineHub is a personal project focused on making it easier to discover movies and TV shows through a simple, modern interface.

> **Note:** This repository is for distributing the CineHub application. The source code is not included.

## Features

- 🎬 Movie & TV show discovery
- 🔎 Advanced search and filtering
- ❤️ Watchlist
- ▶️ Continue Watching
- 📺 TV show episode browser
- 🎥 Built-in video player
- 🔄 Multiple playback sources
- ⭐ Ratings, genres, years and other metadata
- 👥 Cast information
- 🎯 Similar-content recommendations
- 📱 Responsive interface for desktop and mobile

## Download

Download the latest CineHub APK from the **[Releases](../../releases)** section.

### Installation

1. Open the latest release.
2. Download the `.apk` file.
3. If Android asks, allow installation from this source.
4. Install CineHub and open the app.

## Repository Contents

This repository intentionally contains only distribution and documentation files. CineHub's application source code is not published here.

## Third-Party Services

CineHub may use third-party services for metadata, playback, or other functionality. Third-party services and content remain subject to their respective owners' terms, licenses, availability, and policies.

CineHub does not claim ownership of third-party content, trademarks, metadata, or services.

## Disclaimer

CineHub is provided for personal use and experimentation. The availability and legality of third-party sources can vary by region and service. Users are responsible for complying with applicable laws and the terms of services they access through the application.

## License

CineHub is proprietary software. See the [LICENSE](LICENSE) file for usage restrictions.

© 2026 CineHub. All rights reserved.
